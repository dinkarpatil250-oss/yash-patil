/*  InventoryManager.cpp  –  C++ layer wrapping the C backend
 *
 *  STL usage
 *  ---------
 *  std::vector<Item>  – holds the temporary listing fetched from the file.
 *  std::sort          – sorts the vector by id or name before printing.
 */

#include <algorithm>   /* std::sort            */
#include <iomanip>     /* std::setw, std::left */
#include <iostream>
#include <cstring>     /* strncpy              */
#include <vector>

#include "InventoryManager.h"
#include "inventory.h"

/* ------------------------------------------------------------------ */
/*  Private static helpers                                              */
/* ------------------------------------------------------------------ */

Item InventoryManager::makeItem(int id, const std::string &name,
                                int qty, float price, int isDeleted)
{
    Item it{};
    it.id         = id;
    it.quantity   = qty;
    it.price      = price;
    it.is_deleted = isDeleted;
    std::strncpy(it.name, name.c_str(), NAME_LEN - 1);
    it.name[NAME_LEN - 1] = '\0';
    return it;
}

void InventoryManager::printHeader()
{
    std::cout << "\n"
              << std::left
              << std::setw(6)  << "ID"
              << std::setw(42) << "Name"
              << std::setw(10) << "Qty"
              << std::setw(12) << "Price (INR)"
              << "\n"
              << std::string(70, '-') << "\n";
}

void InventoryManager::printItem(const Item &it)
{
    std::cout << std::left
              << std::setw(6)  << it.id
              << std::setw(42) << it.name
              << std::setw(10) << it.quantity
              << std::fixed << std::setprecision(2)
              << std::setw(12) << it.price
              << "\n";
}

/* ------------------------------------------------------------------ */
/*  Public methods                                                      */
/* ------------------------------------------------------------------ */

bool InventoryManager::addItem(int id, const std::string &name,
                               int qty, float price)
{
    Item it = makeItem(id, name, qty, price, 0);
    return add_item(&it) == 1;
}

bool InventoryManager::viewItem(int id)
{
    Item it{};
    if (get_item(id, &it) != 1) return false;

    printHeader();
    printItem(it);
    std::cout << "\n";
    return true;
}

bool InventoryManager::updateItem(int id, const std::string &name,
                                  int qty, float price)
{
    Item it = makeItem(id, name, qty, price, 0);
    return update_item(id, &it) == 1;
}

bool InventoryManager::deleteItem(int id)
{
    return delete_item(id) == 1;
}

void InventoryManager::listAll(bool sortByName)
{
    /* --- STL element 1: std::vector to hold active items temporarily --- */
    std::vector<Item> items(MAX_ITEMS);

    int count = list_items(items.data(), MAX_ITEMS);
    items.resize(static_cast<std::size_t>(count));

    if (items.empty()) {
        std::cout << "\n  (no items in inventory)\n\n";
        return;
    }

    /* --- STL element 2: std::sort to order before display --- */
    if (sortByName) {
        std::sort(items.begin(), items.end(),
                  [](const Item &a, const Item &b) {
                      return std::string(a.name) < std::string(b.name);
                  });
    } else {
        std::sort(items.begin(), items.end(),
                  [](const Item &a, const Item &b) {
                      return a.id < b.id;
                  });
    }

    printHeader();
    for (const auto &it : items) {
        printItem(it);
    }
    std::cout << "\n  Total active items: " << count << "\n\n";
}
