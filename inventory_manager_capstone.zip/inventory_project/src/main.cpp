/*  main.cpp  –  Console menu / UI layer (C++)
 *
 *  Validation rules
 *  ----------------
 *  ID       : positive integer (> 0)
 *  Name     : non-empty string (leading/trailing whitespace stripped)
 *  Quantity : integer >= 0
 *  Price    : float   >= 0.0
 *
 *  Invalid input is rejected and the prompt is repeated – no crashes.
 */

#include <algorithm>   /* std::transform for trim */
#include <cctype>
#include <iostream>
#include <limits>
#include <string>

#include "InventoryManager.h"

/* ------------------------------------------------------------------ */
/*  Input helpers                                                       */
/* ------------------------------------------------------------------ */

/* Flush the remainder of the current input line. */
static void flushLine()
{
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

/* Read a strictly positive integer; loops until valid. */
static int readPositiveInt(const std::string &prompt)
{
    int val;
    for (;;) {
        std::cout << prompt;
        if (std::cin >> val && val > 0) {
            flushLine();
            return val;
        }
        std::cout << "  [!] Must be a positive integer. Try again.\n";
        std::cin.clear();
        flushLine();
    }
}

/* Read an integer >= 0; loops until valid. */
static int readNonNegInt(const std::string &prompt)
{
    int val;
    for (;;) {
        std::cout << prompt;
        if (std::cin >> val && val >= 0) {
            flushLine();
            return val;
        }
        std::cout << "  [!] Must be 0 or greater. Try again.\n";
        std::cin.clear();
        flushLine();
    }
}

/* Read a float >= 0.0; loops until valid. */
static float readNonNegFloat(const std::string &prompt)
{
    float val;
    for (;;) {
        std::cout << prompt;
        if (std::cin >> val && val >= 0.0f) {
            flushLine();
            return val;
        }
        std::cout << "  [!] Must be 0 or greater. Try again.\n";
        std::cin.clear();
        flushLine();
    }
}

/* Read a non-empty trimmed string; loops until valid. */
static std::string readName(const std::string &prompt)
{
    for (;;) {
        std::cout << prompt;
        std::string s;
        std::getline(std::cin, s);

        /* Trim leading whitespace */
        auto start = s.find_first_not_of(" \t\r\n");
        if (start == std::string::npos) {
            std::cout << "  [!] Name cannot be empty. Try again.\n";
            continue;
        }
        /* Trim trailing whitespace */
        auto end = s.find_last_not_of(" \t\r\n");
        s = s.substr(start, end - start + 1);

        if (s.empty()) {
            std::cout << "  [!] Name cannot be empty. Try again.\n";
            continue;
        }
        if (s.size() >= NAME_LEN) {
            std::cout << "  [!] Name too long (max " << NAME_LEN - 1
                      << " chars). Try again.\n";
            continue;
        }
        return s;
    }
}

/* Read a menu choice 1-6; loops until valid. */
static int readMenuChoice()
{
    int val;
    for (;;) {
        std::cout << "  Choice: ";
        if (std::cin >> val && val >= 1 && val <= 6) {
            flushLine();
            return val;
        }
        std::cout << "  [!] Enter a number between 1 and 6.\n";
        std::cin.clear();
        flushLine();
    }
}

/* ------------------------------------------------------------------ */
/*  Menu actions                                                        */
/* ------------------------------------------------------------------ */

static void doAddItem(InventoryManager &mgr)
{
    std::cout << "\n--- ADD ITEM ---\n";
    int         id  = readPositiveInt ("  Item ID   : ");
    std::string nm  = readName        ("  Name      : ");
    int         qty = readNonNegInt   ("  Quantity  : ");
    float       pr  = readNonNegFloat ("  Price     : ");

    if (mgr.addItem(id, nm, qty, pr))
        std::cout << "  [OK] Item " << id << " added successfully.\n\n";
    else
        std::cout << "  [!!] Failed – ID " << id
                  << " may already exist or an I/O error occurred.\n\n";
}

static void doViewItem(InventoryManager &mgr)
{
    std::cout << "\n--- VIEW ITEM ---\n";
    int id = readPositiveInt("  Item ID: ");

    if (!mgr.viewItem(id))
        std::cout << "  [!!] Item " << id << " not found or has been deleted.\n\n";
}

static void doUpdateItem(InventoryManager &mgr)
{
    std::cout << "\n--- UPDATE ITEM ---\n";
    int id = readPositiveInt("  Item ID to update: ");

    /* Let the user see the current record first. */
    if (!mgr.viewItem(id)) {
        std::cout << "  [!!] Item " << id
                  << " not found or has been deleted.\n\n";
        return;
    }

    std::cout << "  Enter new values:\n";
    std::string nm  = readName        ("  Name      : ");
    int         qty = readNonNegInt   ("  Quantity  : ");
    float       pr  = readNonNegFloat ("  Price     : ");

    if (mgr.updateItem(id, nm, qty, pr))
        std::cout << "  [OK] Item " << id << " updated.\n\n";
    else
        std::cout << "  [!!] Update failed.\n\n";
}

static void doDeleteItem(InventoryManager &mgr)
{
    std::cout << "\n--- DELETE ITEM ---\n";
    int id = readPositiveInt("  Item ID to delete: ");

    if (mgr.deleteItem(id))
        std::cout << "  [OK] Item " << id << " deleted.\n\n";
    else
        std::cout << "  [!!] Item " << id << " not found.\n\n";
}

static void doListAll(InventoryManager &mgr)
{
    std::cout << "\n--- LIST ALL ITEMS ---\n";
    std::cout << "  Sort by: (1) ID  (2) Name  [default=1]: ";
    int choice;
    bool sortByName = false;
    if (std::cin >> choice) {
        sortByName = (choice == 2);
    }
    std::cin.clear();
    flushLine();

    mgr.listAll(sortByName);
}

/* ------------------------------------------------------------------ */
/*  Menu display                                                        */
/* ------------------------------------------------------------------ */

static void printMenu()
{
    std::cout << "\n"
              << "========================================\n"
              << "       HYBRID INVENTORY MANAGER         \n"
              << "========================================\n"
              << "  1  Add item\n"
              << "  2  View item\n"
              << "  3  Update item\n"
              << "  4  Delete item\n"
              << "  5  List all\n"
              << "  6  Exit\n"
              << "----------------------------------------\n";
}

/* ------------------------------------------------------------------ */
/*  main                                                                */
/* ------------------------------------------------------------------ */

int main()
{
    InventoryManager mgr;

    std::cout << "\nWelcome to Hybrid Inventory Manager\n"
              << "Data file: " << DB_FILENAME << "\n";

    for (;;) {
        printMenu();
        int choice = readMenuChoice();

        switch (choice) {
            case 1: doAddItem(mgr);    break;
            case 2: doViewItem(mgr);   break;
            case 3: doUpdateItem(mgr); break;
            case 4: doDeleteItem(mgr); break;
            case 5: doListAll(mgr);    break;
            case 6:
                std::cout << "\nGoodbye!\n\n";
                return 0;
        }
    }
}
