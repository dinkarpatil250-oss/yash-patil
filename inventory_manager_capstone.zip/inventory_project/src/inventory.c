/*  inventory.c  –  C backend: binary-file CRUD for Item records
 *
 *  File layout: a flat sequence of Item structs written with fwrite / fread.
 *  Each record occupies exactly sizeof(Item) bytes, so record N starts at
 *  offset  N * sizeof(Item).  Soft-delete sets is_deleted = 1 in place.
 */

#include <stdio.h>
#include <string.h>
#include "inventory.h"

/* ------------------------------------------------------------------ */
/*  Internal helpers                                                    */
/* ------------------------------------------------------------------ */

/* Open the database file.  mode must be a valid fopen mode string.     */
static FILE *open_db(const char *mode)
{
    return fopen(DB_FILENAME, mode);
}

/* Find the file offset (in record units) of the item with given id.
 * Returns the record index (>= 0) on success, -1 if not found.
 * Fills *out if out != NULL (even for deleted records).               */
static long find_record_index(FILE *fp, int id, Item *out)
{
    Item   tmp;
    long   idx = 0;

    rewind(fp);
    while (fread(&tmp, sizeof(Item), 1, fp) == 1) {
        if (tmp.id == id) {
            if (out) *out = tmp;
            return idx;
        }
        idx++;
    }
    return -1L;
}

/* ------------------------------------------------------------------ */
/*  Public API                                                          */
/* ------------------------------------------------------------------ */

/* add_item – append a new record; reject duplicate ids.
 * Returns 1 on success, 0 on failure.                                 */
int add_item(const Item *item)
{
    FILE *fp;
    Item  tmp;

    if (!item) return 0;

    /* Try to open existing file for reading to check duplicates.       */
    fp = open_db("rb");
    if (fp) {
        long idx = find_record_index(fp, item->id, &tmp);
        fclose(fp);
        if (idx >= 0) return 0;   /* duplicate id */
    }

    /* Append the new record.                                           */
    fp = open_db("ab");
    if (!fp) return 0;

    int ok = (fwrite(item, sizeof(Item), 1, fp) == 1);
    fclose(fp);
    return ok;
}

/* get_item – load one active record by id.
 * Returns 1 on success, 0 if not found or soft-deleted.              */
int get_item(int id, Item *out)
{
    FILE *fp;
    Item  tmp;

    if (!out) return 0;

    fp = open_db("rb");
    if (!fp) return 0;

    long idx = find_record_index(fp, id, &tmp);
    fclose(fp);

    if (idx < 0 || tmp.is_deleted) return 0;

    *out = tmp;
    return 1;
}

/* update_item – overwrite an existing active record in place.
 * Returns 1 on success, 0 if not found or soft-deleted.              */
int update_item(int id, const Item *updated)
{
    FILE *fp;
    Item  tmp;
    long  offset;

    if (!updated) return 0;

    fp = open_db("r+b");
    if (!fp) return 0;

    long idx = find_record_index(fp, id, &tmp);
    if (idx < 0 || tmp.is_deleted) {
        fclose(fp);
        return 0;
    }

    offset = idx * (long)sizeof(Item);
    if (fseek(fp, offset, SEEK_SET) != 0) {
        fclose(fp);
        return 0;
    }

    int ok = (fwrite(updated, sizeof(Item), 1, fp) == 1);
    fclose(fp);
    return ok;
}

/* delete_item – soft-delete: set is_deleted = 1 for the given id.
 * Returns 1 on success, 0 if not found.                               */
int delete_item(int id)
{
    FILE *fp;
    Item  tmp;
    long  offset;

    fp = open_db("r+b");
    if (!fp) return 0;

    long idx = find_record_index(fp, id, &tmp);
    if (idx < 0) {
        fclose(fp);
        return 0;
    }

    tmp.is_deleted = 1;
    offset = idx * (long)sizeof(Item);

    if (fseek(fp, offset, SEEK_SET) != 0) {
        fclose(fp);
        return 0;
    }

    int ok = (fwrite(&tmp, sizeof(Item), 1, fp) == 1);
    fclose(fp);
    return ok;
}

/* list_items – copy all active (non-deleted) records into buffer.
 * Returns the number of items copied (0 if file absent or empty).    */
int list_items(Item *buffer, int max_items)
{
    FILE *fp;
    Item  tmp;
    int   count = 0;

    if (!buffer || max_items <= 0) return 0;

    fp = open_db("rb");
    if (!fp) return 0;

    while (count < max_items && fread(&tmp, sizeof(Item), 1, fp) == 1) {
        if (!tmp.is_deleted) {
            buffer[count++] = tmp;
        }
    }
    fclose(fp);
    return count;
}
