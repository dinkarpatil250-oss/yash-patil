# Hybrid Inventory Manager

A console-based inventory management system that demonstrates C/C++ interoperability:

- **C layer** (`inventory.c`) – binary file I/O using `fread`/`fwrite`/`fseek`
- **C++ layer** (`InventoryManager.cpp`, `main.cpp`) – OOP wrapper, STL (`std::vector`, `std::sort`), input validation, console menu

Data persists across runs in **`inventory.dat`** (binary, same directory as the executable).

---

## Project Structure

```
inventory_project/
├── include/
│   ├── inventory.h          # C struct + function declarations (extern "C")
│   └── InventoryManager.h   # C++ class declaration
├── src/
│   ├── inventory.c          # C backend (CRUD + binary file)
│   ├── InventoryManager.cpp # C++ wrapper (std::vector, std::sort)
│   └── main.cpp             # Menu UI + input validation
├── Makefile
├── CMakeLists.txt
└── README.md
```

---

## Build & Run

### Option A – Make (Linux / macOS / WSL)

```bash
cd inventory_project
make          # builds ./inventory_manager
./inventory_manager
```

To clean all build artifacts **and the data file**:
```bash
make clean
```

### Option B – CMake

```bash
cd inventory_project
cmake -B build
cmake --build build
./build/inventory_manager
```

> **Requirements:** `gcc` ≥ 9, `g++` ≥ 9, GNU Make ≥ 3.81 or CMake ≥ 3.12.

---

## Item Data Format

| Field        | Type       | Notes                              |
|--------------|------------|------------------------------------|
| `id`         | `int`      | Unique positive integer            |
| `name`       | `char[40]` | Non-empty string, max 39 chars     |
| `quantity`   | `int`      | ≥ 0                                |
| `price`      | `float`    | ≥ 0.0                              |
| `is_deleted` | `int`      | 0 = active, 1 = soft-deleted       |

Records are written as fixed-size binary blobs (`sizeof(Item)` bytes each).  
`fseek(offset = index × sizeof(Item))` locates any record for in-place update or soft-delete.

---

## Menu

```
========================================
       HYBRID INVENTORY MANAGER
========================================
  1  Add item
  2  View item
  3  Update item
  4  Delete item
  5  List all
  6  Exit
```

---

## Input Validation

| Field    | Rule                          | Behaviour on failure        |
|----------|-------------------------------|-----------------------------|
| ID       | Positive integer (> 0)        | Re-prompts with error msg   |
| Name     | Non-empty, ≤ 39 chars         | Re-prompts with error msg   |
| Quantity | Integer ≥ 0                   | Re-prompts with error msg   |
| Price    | Float ≥ 0.0                   | Re-prompts with error msg   |
| Menu     | Integer 1–6                   | Re-prompts with error msg   |

---

## Test Cases

- **TC-1 – Persistence across restart**  
  Added items with IDs 1, 2, 3 (Pencil, Notebook, Eraser). Exited with option 6. Relaunched the program and chose "List all" – all three items appeared correctly. ✅

- **TC-2 – Duplicate ID rejection**  
  Tried to add a second item with ID 1 while item 1 already existed. Program printed a failure message and did not create a duplicate. ✅

- **TC-3 – Update persists after restart**  
  Updated item ID 2 ("Notebook") to new name "Spiral Notebook", qty 50, price 45.00. Exited. Relaunched and viewed item 2 – new values were shown. ✅

- **TC-4 – Soft-delete hides item**  
  Deleted item ID 3 ("Eraser"). Chose "List all" – only IDs 1 and 2 appeared. Chose "View item" for ID 3 – program reported "not found or deleted". ✅

- **TC-5 – Invalid input recovery**  
  Entered `-5` for ID → error, re-prompted. Entered `0` for quantity → accepted. Entered `-1.5` for price → error, re-prompted. Entered empty string for name → error, re-prompted. Program never crashed. ✅

---

## Design Notes

### Why binary storage?

Fixed-size records let `fseek` jump directly to any record (`index × sizeof(Item)`) for O(1) in-place updates and deletes – no rewriting the entire file.

### Soft-delete

`is_deleted = 1` marks a record invisible without freeing its slot. This preserves the fixed-index addressing and makes the ID permanently unavailable for reuse (duplicate-ID check still matches deleted records).

### STL usage

- `std::vector<Item>` – holds the temporary snapshot returned by `list_items()`.
- `std::sort` with a lambda – sorts the snapshot by `id` or `name` before display.

### `extern "C"` guard

`inventory.h` wraps all declarations in `extern "C"` so the C++ linker uses C name mangling for the backend symbols.
