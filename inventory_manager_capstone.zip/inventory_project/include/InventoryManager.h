#ifndef INVENTORY_MANAGER_H
#define INVENTORY_MANAGER_H

#include <vector>
#include <string>
#include "inventory.h"

/* InventoryManager
 * ----------------
 * Thin C++ wrapper around the C backend.
 * Exposes a clean, exception-free interface and owns no persistent state
 * (all data lives in the binary file managed by inventory.c).
 */
class InventoryManager {
public:
    /* Attempt to add item; returns false on duplicate id / I/O error. */
    bool addItem(int id, const std::string &name, int qty, float price);

    /* Print a single active item; returns false if not found.         */
    bool viewItem(int id);

    /* Overwrite an existing active record; returns false on failure.  */
    bool updateItem(int id, const std::string &name, int qty, float price);

    /* Soft-delete a record; returns false if not found.               */
    bool deleteItem(int id);

    /* Print all active items, sorted by id (default) or by name.
     * sortByName=true sorts alphabetically.                           */
    void listAll(bool sortByName = false);

private:
    static constexpr int MAX_ITEMS = 1024;

    /* Build Item struct from parts. */
    static Item makeItem(int id, const std::string &name, int qty, float price,
                         int isDeleted = 0);

    /* Pretty-print a single Item row. */
    static void printItem(const Item &it);

    /* Print the table header. */
    static void printHeader();
};

#endif /* INVENTORY_MANAGER_H */
